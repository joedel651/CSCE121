//Joseph DeLeonardis
//CSCE 121-101
//Due: June 6, 2016
//hw1pr1.cpp
#include "std_lib_facilities_4.h"


//this program shows the hints of a 15 word cross word puzzle

int main() {
	
	//all the hints listed below with the word and number next to it
	
	cout<<"\nAn alternative way of referring to an object; often a name, pointer or reference.\n"<<endl; //alias 1
	
	cout<<"A program or a part of a program; ambiguously used for both source code and object code.\n"<<endl; //code 2
	
	cout<<"The act of searching for and removing errors from a program; usually far less systematic than testing\n"<<endl; //debugging 3
	
	cout<<"A mismatch between reasonable expectations of program behavior (often expressed as a requirement or a users' guide) and what a program actaully does.\n"<<endl; //error 4
	
	cout<<"A container of permanent information in a computer.\n"<<endl; // file 5
	
	cout<<" A loop where the termination condition never becomes true.\n "<<endl; // infinate loop 6
	
	cout<<"producing a value that cannot be stored in its intended target.\n"<<endl; // overflow 7
	
	cout<<"A program that combines object code files and libraries into an executable program.\n"<<endl; // linker 8
	
	cout<<"A whole number, such as 42 and -99.\n"<<endl; // integer 9
	
	cout<<" The region of program text (source code) in which a name can be referred to.\n"<<endl; // scope 9 
	
	cout<<"An object responsible for releasing a source.\n"<<endl; // owner 10
	
	cout<<"A value used to identify a typed object in memory; (2) a Variable holding such a value.\n"<<endl; //pointer 11
	
	cout<<"code (possibly with associated data) that is sufficiently complete to be executed by a computer.\n"<<endl; //program 12
	
	cout<< "A basic unit of memory in a computer, usually the unit used to hold an integer.\n"<<endl; // word 13	
	
	cout<<"Something that defines a set of possible values and a set of operations for an object.\n"<<endl; // type 14
	
	cout<<"A systematic search for errors in a program.\n"<<endl; // testing 15
	
	
	
	return 0;
}